Twitch badge flair overlays

Tier2_SilverCrystal: subscription tier 2
Tier3_GoldCrown: subscription tier 3

Upload 18.png, 36.png, 72.png from matching tier folder. Transparent static overlays, not replacement subscriber badges. The corner ornament appears over the existing loyalty badge. Each file is below 25 KB.
