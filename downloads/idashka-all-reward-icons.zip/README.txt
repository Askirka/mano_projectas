Значки наград idashka_zxc

В каждой папке 28.png, 56.png и 112.png. Загружайте их в соответствующие поля Twitch. Прозрачные статичные PNG, все меньше 25 КБ.

01_HighlightMessage: Выделить моё сообщение
02_RandomEmote: Разблокировать случайный смайлик
03_SubscriberMessage: Сообщение в режиме только для подписчиков
04_ChooseEmote: Выбор смайлика для разблокировки
05_ModifyEmote: Изменение смайлика
06_Music: Поставить музыку
07_MatchJudge: Суд над моей каткой
08_HeroVoice: Голос в моей голове
09_ChooseHero: Герой от инвестора
10_ReplayCoach: Мой личный тренер
11_ViewerBuild: Скинь мне билд
12_SignatureHero: Контракт на сигнатурку
13_ViewerLobby: Лобби имени легенды
14_StreamDirector: Режиссёр стрима
