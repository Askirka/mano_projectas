Twitch subscriber badges / idashka_zxc

00_base: Basic
02_months: 2 months
03_months: 3 months
06_months: 6 months
09_months: 9 months
12_months: 1 year

Choose the corresponding subscription duration in Twitch. Upload 18.png, 36.png and 72.png from that folder into their matching size slots. Static transparent PNGs, each below 25 KB.
